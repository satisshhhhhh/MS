### To take backup of Mysql database
```
mysql -u root -p
sudo mysqldump -u root -p <database_name> > bak.sql
```

### To restore the backup file back to Mysql
```
sudo mysql -u root -p <database_name> < bak.sql
```
