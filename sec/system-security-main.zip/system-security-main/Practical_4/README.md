# Study of Brute Force Attack & A Program to Create a Virus

### Brute Force Attack
A brute force attack uses trial-and-error to guess login info, encryption keys, or find a hidden web page. Hackers work through all possible combinations hoping to guess correctly.

These attacks are done by ‘brute force’ meaning they use excessive forceful attempts to try and ‘force’ their way into your private account(s).

This is an old attack method, but it's still effective and popular with hackers. Because depending on the length and complexity of the password, cracking it can take anywhere from a few seconds to many years.

> Click here for virus code : [Brute_force.py](https://github.com/Encryptor-Sec/system-security/blob/main/Practical_4/Brute_force.py)

This python-based brute force tool is created in a such a way that it can break any kind of password (only smallcase) with no limitation on the length of the password. Remember the longer the password the more time it will take to break it

#### Sample output
```
Enter your password : sathya
Bruteforcing your password: 
Your password is :  sathya
```

### Virus
A computer virus is a type of malicious software, or malware, that spreads between computers and causes damage to data and software. 

Computer viruses aim to disrupt systems, cause major operational issues, and result in data loss and leakage. A key thing to know about computer viruses is that they are designed to spread across programs and systems. Computer viruses typically attach to an executable host file, which results in their viral codes executing when a file is opened. The code then spreads from the document or software it is attached to via networks, drives, file-sharing programs, or infected email attachments.

> Click here for virus code : [virus.py](https://github.com/Encryptor-Sec/system-security/blob/main/Practical_4/virus.py)

This python-based virus is created in such a way that when the virus program is executed, any python programs or.py files in the current directory are replaced with new code that is identical to the virus code, and the old code is permanently removed. 

**Note** : a file called [Normal_program.py](https://github.com/Encryptor-Sec/system-security/blob/main/Practical_4/Normal_program.py) is added in the repo for testing purposes. If the virus file is executed then the same code of **virus.py** will be copied to **Normal_program.py**.
